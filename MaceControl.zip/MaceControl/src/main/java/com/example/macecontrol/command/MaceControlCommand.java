package com.example.macecontrol.command;

import com.example.macecontrol.MaceControlPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MaceControlCommand implements CommandExecutor {

    private final MaceControlPlugin plugin;

    public MaceControlCommand(MaceControlPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Double-enforced: plugin.yml permission defaults to op, and we also
        // hard-check isOp() here so permission plugins can't accidentally
        // grant non-ops access to mace enchant controls.
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by a player in-game.");
            return true;
        }
        if (!player.isOp() && !player.hasPermission("macecontrol.admin")) {
            player.sendMessage("\u00a7cYou must be an operator to use Mace Control.");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("stats")) {
            plugin.getGui().sendStats(player);
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            plugin.getRules().reload();
            player.sendMessage("\u00a7aMaceControl config reloaded.");
            return true;
        }

        player.openInventory(plugin.getGui().build());
        return true;
    }
}
