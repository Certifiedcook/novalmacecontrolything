package com.example.macecontrol.gui;

import com.example.macecontrol.MaceControlPlugin;
import com.example.macecontrol.data.EnchantRules;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds and refreshes the /macecontrol chest GUI. Layout is a 54-slot
 * inventory: enchantment toggles in the middle, control buttons on the
 * bottom row, everything else filled with a border pane.
 */
public class MaceControlGUI {

    public static final String TITLE = "\u00a75\u00a7lMace Control Panel";
    public static final int SIZE = 54;

    public static final int SLOT_STATS = 38;
    public static final int SLOT_RELOAD = 40;
    public static final int SLOT_CLOSE = 42;

    // First content slot; enchantments are laid out sequentially, skipping
    // border columns (0 and 8 of each 9-wide row).
    private static final int[] CONTENT_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25
    };

    private final MaceControlPlugin plugin;

    // Maps a clicked slot back to the enchantment it represents, per open GUI.
    private final Map<Integer, Enchantment> slotMap = new LinkedHashMap<>();

    public MaceControlGUI(MaceControlPlugin plugin) {
        this.plugin = plugin;
    }

    public Map<Integer, Enchantment> getSlotMap() {
        return slotMap;
    }

    public Inventory build() {
        Inventory inv = plugin.getServer().createInventory(null, SIZE, Component.text(TITLE));
        slotMap.clear();

        ItemStack border = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < SIZE; i++) inv.setItem(i, border);

        EnchantRules rules = plugin.getRules();
        List<Enchantment> enchants = new ArrayList<>(rules.all().keySet());

        for (int i = 0; i < enchants.size() && i < CONTENT_SLOTS.length; i++) {
            Enchantment ench = enchants.get(i);
            int slot = CONTENT_SLOTS[i];
            inv.setItem(slot, buildEnchantItem(ench, rules));
            slotMap.put(slot, ench);
        }

        inv.setItem(SLOT_STATS, namedItem(Material.PAPER, NamedTextColor.AQUA, "View Stats",
                List.of("\u00a77Click to see allowed / blocked", "\u00a77mace enchant attempts.")));
        inv.setItem(SLOT_RELOAD, namedItem(Material.REDSTONE, NamedTextColor.YELLOW, "Reload Config",
                List.of("\u00a77Re-read config.yml from disk.")));
        inv.setItem(SLOT_CLOSE, namedItem(Material.BARRIER, NamedTextColor.RED, "Close",
                List.of("\u00a77Close this panel.")));

        return inv;
    }

    /** Rebuilds a single enchant slot in-place after a toggle/level change. */
    public void refreshSlot(Inventory inv, int slot, Enchantment ench) {
        inv.setItem(slot, buildEnchantItem(ench, plugin.getRules()));
    }

    private ItemStack buildEnchantItem(Enchantment ench, EnchantRules rules) {
        EnchantRules.Rule rule = rules.ruleFor(ench);
        boolean enabled = rule != null && rule.enabled;
        int maxLevel = rule != null ? rule.maxLevel : 0;

        Material icon = enabled ? Material.ENCHANTED_BOOK : Material.BOOK;
        NamedTextColor color = enabled ? NamedTextColor.GREEN : NamedTextColor.GRAY;
        String name = prettify(ench.getKey().getKey());

        List<String> lore = new ArrayList<>();
        lore.add((enabled ? "\u00a7aENABLED" : "\u00a7cDISABLED") + " \u00a77on Mace");
        lore.add("\u00a77Max level: \u00a7f" + maxLevel);
        lore.add("");
        lore.add("\u00a7eLeft-click\u00a77 to toggle enabled");
        lore.add("\u00a7eRight-click\u00a77 to raise max level");
        lore.add("\u00a7eShift-right-click\u00a77 to lower max level");

        return namedItem(icon, color, name, lore);
    }

    private ItemStack namedItem(Material material, NamedTextColor color, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        List<Component> loreComponents = new ArrayList<>();
        for (String line : lore) {
            loreComponents.add(Component.text(line).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(loreComponents);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack pane(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name).decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);
        return item;
    }

    private String prettify(String key) {
        String[] parts = key.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }

    public void sendStats(Player player) {
        var tracker = plugin.getTracker();
        player.sendMessage(Component.text("\u00a75\u00a7l--- Mace Control Stats ---"));
        player.sendMessage(Component.text("\u00a77Total allowed: \u00a7a" + tracker.getTotalAllowed()));
        player.sendMessage(Component.text("\u00a77Total blocked: \u00a7c" + tracker.getTotalBlocked()));
        long[] mine = tracker.getStatsFor(player.getUniqueId());
        player.sendMessage(Component.text("\u00a77Your allowed/blocked: \u00a7a" + mine[0] + "\u00a77/\u00a7c" + mine[1]));
    }
}
