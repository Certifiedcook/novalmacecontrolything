package com.example.macecontrol.gui;

import com.example.macecontrol.MaceControlPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIListener implements Listener {

    private final MaceControlPlugin plugin;

    public GUIListener(MaceControlPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Component titleComponent = event.getView().title();
        String title = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                .serialize(titleComponent);
        String expected = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                .serialize(Component.text(MaceControlGUI.TITLE));
        if (!title.equals(expected)) return;

        event.setCancelled(true); // never allow taking items out of the panel

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!player.isOp() && !player.hasPermission("macecontrol.admin")) {
            player.closeInventory();
            player.sendMessage("\u00a7cOnly operators may use Mace Control.");
            return;
        }

        int slot = event.getRawSlot();
        MaceControlGUI gui = plugin.getGui();

        if (slot == MaceControlGUI.SLOT_CLOSE) {
            player.closeInventory();
            return;
        }
        if (slot == MaceControlGUI.SLOT_STATS) {
            gui.sendStats(player);
            return;
        }
        if (slot == MaceControlGUI.SLOT_RELOAD) {
            plugin.getRules().reload();
            player.sendMessage("\u00a7aMaceControl config reloaded.");
            player.getOpenInventory().getTopInventory().setContents(gui.build().getContents());
            return;
        }

        Enchantment ench = gui.getSlotMap().get(slot);
        if (ench == null) return;

        ClickType click = event.getClick();
        if (click == ClickType.LEFT) {
            plugin.getRules().toggle(ench);
        } else if (click == ClickType.RIGHT) {
            plugin.getRules().bumpMaxLevel(ench, 1, 1, 10);
        } else if (click == ClickType.SHIFT_RIGHT) {
            plugin.getRules().bumpMaxLevel(ench, -1, 1, 10);
        } else {
            return;
        }

        plugin.getRules().save();
        gui.refreshSlot(event.getInventory(), slot, ench);
    }
}
