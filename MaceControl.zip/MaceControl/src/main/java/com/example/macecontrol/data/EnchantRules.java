package com.example.macecontrol.data;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * In-memory view of the "enchantments" section of config.yml, with helpers
 * to check/toggle/cap rules and persist changes back to disk.
 */
public class EnchantRules {

    public static class Rule {
        public boolean enabled;
        public int maxLevel;

        public Rule(boolean enabled, int maxLevel) {
            this.enabled = enabled;
            this.maxLevel = maxLevel;
        }
    }

    private final JavaPlugin plugin;
    // Insertion-ordered so the GUI has a stable layout
    private final Map<Enchantment, Rule> rules = new LinkedHashMap<>();

    public EnchantRules(JavaPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    /** Re-reads config.yml into memory. */
    public void reload() {
        rules.clear();
        plugin.reloadConfig();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("enchantments");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            Enchantment ench = resolveEnchantment(key);
            if (ench == null) {
                plugin.getLogger().warning("Unknown enchantment key in config.yml: " + key);
                continue;
            }
            boolean enabled = section.getBoolean(key + ".enabled", false);
            int maxLevel = Math.max(1, section.getInt(key + ".max-level", 1));
            rules.put(ench, new Rule(enabled, maxLevel));
        }
    }

    /** Writes the current in-memory rules back into config.yml and saves it. */
    public void save() {
        ConfigurationSection section = plugin.getConfig().createSection("enchantments");
        for (var entry : rules.entrySet()) {
            String key = keyFor(entry.getKey());
            section.set(key + ".enabled", entry.getValue().enabled);
            section.set(key + ".max-level", entry.getValue().maxLevel);
        }
        plugin.saveConfig();
    }

    public Map<Enchantment, Rule> all() {
        return rules;
    }

    public Rule ruleFor(Enchantment ench) {
        return rules.get(ench);
    }

    /** True if this enchantment is allowed on a mace at the given level. */
    public boolean isAllowed(Enchantment ench, int level) {
        Rule r = rules.get(ench);
        if (r == null) return false; // unknown enchantments are disallowed by default
        return r.enabled && level <= r.maxLevel;
    }

    /** The highest level allowed for this enchantment (0 if disabled entirely). */
    public int maxAllowedLevel(Enchantment ench) {
        Rule r = rules.get(ench);
        if (r == null || !r.enabled) return 0;
        return r.maxLevel;
    }

    public void toggle(Enchantment ench) {
        Rule r = rules.get(ench);
        if (r != null) r.enabled = !r.enabled;
    }

    public void bumpMaxLevel(Enchantment ench, int delta, int minLevel, int cap) {
        Rule r = rules.get(ench);
        if (r == null) return;
        int newLevel = r.maxLevel + delta;
        if (newLevel < minLevel) newLevel = cap;
        if (newLevel > cap) newLevel = minLevel;
        r.maxLevel = newLevel;
    }

    private String keyFor(Enchantment ench) {
        return ench.getKey().getKey().toUpperCase();
    }

    @SuppressWarnings("deprecation")
    private Enchantment resolveEnchantment(String key) {
        try {
            // Legacy static field lookup, still valid across 1.20-1.21 API surfaces.
            return Enchantment.class.getField(key.toUpperCase()).get(null) instanceof Enchantment e ? e : null;
        } catch (Exception ex) {
            // Fallback: try Bukkit's namespaced key registry ("minecraft:density" style keys)
            return Enchantment.getByKey(org.bukkit.NamespacedKey.minecraft(key.toLowerCase()));
        }
    }
}
