package com.example.macecontrol.listeners;

import com.example.macecontrol.MaceControlPlugin;
import com.example.macecontrol.data.EnchantRules;
import com.example.macecontrol.data.EnchantTracker;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MaceEnchantListener implements Listener {

    private final MaceControlPlugin plugin;

    public MaceEnchantListener(MaceControlPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isMace(ItemStack item) {
        return item != null && item.getType() == Material.MACE;
    }

    // ---- Enchanting table ----
    @EventHandler
    public void onEnchantItem(EnchantItemEvent event) {
        if (!isMace(event.getItem())) return;

        EnchantRules rules = plugin.getRules();
        EnchantTracker tracker = plugin.getTracker();
        Player player = event.getEnchanter();

        Map<Enchantment, Integer> toAdd = event.getEnchantsToAdd();
        Iterator<Map.Entry<Enchantment, Integer>> it = toAdd.entrySet().iterator();
        boolean anyBlocked = false;

        while (it.hasNext()) {
            Map.Entry<Enchantment, Integer> entry = it.next();
            Enchantment ench = entry.getKey();
            int level = entry.getValue();

            if (rules.isAllowed(ench, level)) {
                tracker.recordAllowed(player, ench.getKey().getKey(), level);
            } else {
                int cappedLevel = rules.maxAllowedLevel(ench);
                if (cappedLevel > 0) {
                    // allowed but at a lower level than the table rolled
                    entry.setValue(cappedLevel);
                    tracker.recordAllowed(player, ench.getKey().getKey(), cappedLevel);
                } else {
                    it.remove();
                    tracker.recordBlocked(player, ench.getKey().getKey(), level);
                    anyBlocked = true;
                }
            }
        }

        if (anyBlocked) {
            notifyOps(player.getName() + " tried to enchant a Mace with a disallowed enchantment (table). Blocked/capped automatically.");
        }
    }

    // ---- Anvil (books, combining) ----
    @EventHandler
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        ItemStack result = event.getResult();
        if (!isMace(result)) return;

        ItemMeta meta = result.getItemMeta();
        if (meta == null || meta.getEnchants().isEmpty()) return;

        EnchantRules rules = plugin.getRules();
        Player player = (Player) event.getView().getPlayer();
        boolean changed = false;

        Map<Enchantment, Integer> current = new HashMap<>(meta.getEnchants());
        for (var entry : current.entrySet()) {
            Enchantment ench = entry.getKey();
            int level = entry.getValue();

            if (!rules.isAllowed(ench, level)) {
                int cappedLevel = rules.maxAllowedLevel(ench);
                meta.removeEnchant(ench);
                if (cappedLevel > 0) {
                    meta.addEnchant(ench, cappedLevel, true);
                    plugin.getTracker().recordAllowed(player, ench.getKey().getKey(), cappedLevel);
                } else {
                    plugin.getTracker().recordBlocked(player, ench.getKey().getKey(), level);
                }
                changed = true;
            } else {
                plugin.getTracker().recordAllowed(player, ench.getKey().getKey(), level);
            }
        }

        if (changed) {
            result.setItemMeta(meta);
            event.setResult(result);
            notifyOps(player.getName() + " tried to combine a Mace with a disallowed enchantment (anvil). Blocked/capped automatically.");
        }
    }

    // ---- Join sweep: catch items enchanted before rules existed, or given via /give ----
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!plugin.getConfig().getBoolean("settings.strip-illegal-on-join", true)) return;
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> sanitizeInventory(player), 20L);
    }

    /** Removes/caps disallowed enchants from every Mace in a player's inventory. */
    public void sanitizeInventory(Player player) {
        EnchantRules rules = plugin.getRules();
        boolean any = false;

        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && sanitizeItem(item, rules, player)) any = true;
        }
        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (sanitizeItem(offHand, rules, player)) any = true;

        if (any) {
            player.updateInventory();
            notifyOps("Stripped disallowed mace enchantments from " + player.getName() + "'s inventory.");
        }
    }

    private boolean sanitizeItem(ItemStack item, EnchantRules rules, Player player) {
        if (!isMace(item)) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || meta.getEnchants().isEmpty()) return false;

        boolean changed = false;
        Map<Enchantment, Integer> current = new HashMap<>(meta.getEnchants());
        for (var entry : current.entrySet()) {
            Enchantment ench = entry.getKey();
            int level = entry.getValue();
            if (!rules.isAllowed(ench, level)) {
                int cappedLevel = rules.maxAllowedLevel(ench);
                meta.removeEnchant(ench);
                if (cappedLevel > 0) {
                    meta.addEnchant(ench, cappedLevel, true);
                }
                plugin.getTracker().recordBlocked(player, ench.getKey().getKey(), level);
                changed = true;
            }
        }
        if (changed) item.setItemMeta(meta);
        return changed;
    }

    private void notifyOps(String message) {
        if (!plugin.getConfig().getBoolean("settings.notify-ops-on-block", true)) return;
        plugin.getServer().getOnlinePlayers().stream()
                .filter(Player::isOp)
                .forEach(p -> p.sendMessage("\u00a7c[MaceControl] \u00a7f" + message));
    }
}
