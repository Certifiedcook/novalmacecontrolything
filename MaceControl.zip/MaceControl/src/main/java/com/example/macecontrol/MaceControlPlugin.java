package com.example.macecontrol;

import com.example.macecontrol.command.MaceControlCommand;
import com.example.macecontrol.data.EnchantRules;
import com.example.macecontrol.data.EnchantTracker;
import com.example.macecontrol.gui.GUIListener;
import com.example.macecontrol.gui.MaceControlGUI;
import com.example.macecontrol.listeners.MaceEnchantListener;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class MaceControlPlugin extends JavaPlugin {

    private EnchantRules rules;
    private EnchantTracker tracker;
    private MaceControlGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.rules = new EnchantRules(this);
        this.tracker = new EnchantTracker(this);
        this.gui = new MaceControlGUI(this);

        getServer().getPluginManager().registerEvents(new MaceEnchantListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        var executor = new MaceControlCommand(this);
        getCommand("macecontrol").setExecutor(executor);

        if (getConfig().getBoolean("settings.periodic-sweep", true)) {
            long intervalTicks = getConfig().getLong("settings.periodic-sweep-interval-seconds", 15) * 20L;
            var listener = new MaceEnchantListener(this);
            getServer().getScheduler().runTaskTimer(this, () -> {
                for (Player p : getServer().getOnlinePlayers()) {
                    listener.sanitizeInventory(p);
                }
            }, intervalTicks, intervalTicks);
        }

        getLogger().info("MaceControl enabled - managing enchantments on Mace items.");
    }

    @Override
    public void onDisable() {
        if (tracker != null) tracker.save();
        if (rules != null) rules.save();
    }

    public EnchantRules getRules() {
        return rules;
    }

    public EnchantTracker getTracker() {
        return tracker;
    }

    public MaceControlGUI getGui() {
        return gui;
    }
}
