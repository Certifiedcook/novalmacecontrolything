package com.example.macecontrol.data;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;

/**
 * Keeps count of allowed / blocked mace enchant attempts, in memory and
 * persisted to a small YAML file so stats survive restarts.
 */
public class EnchantTracker {

    private final JavaPlugin plugin;
    private final File file;

    private final AtomicLong totalAllowed = new AtomicLong();
    private final AtomicLong totalBlocked = new AtomicLong();

    // Per-player counters: UUID -> [allowed, blocked]
    private final ConcurrentHashMap<UUID, long[]> perPlayer = new ConcurrentHashMap<>();

    public EnchantTracker(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "tracker.yml");
        load();
    }

    public void recordAllowed(Player player, String enchantKey, int level) {
        totalAllowed.incrementAndGet();
        perPlayer.computeIfAbsent(player.getUniqueId(), k -> new long[2])[0]++;
        plugin.getLogger().fine("Allowed " + enchantKey + " " + level + " on mace for " + player.getName());
    }

    public void recordBlocked(Player player, String enchantKey, int level) {
        totalBlocked.incrementAndGet();
        perPlayer.computeIfAbsent(player.getUniqueId(), k -> new long[2])[1]++;
        plugin.getLogger().fine("Blocked " + enchantKey + " " + level + " on mace for " + player.getName());
    }

    public long getTotalAllowed() {
        return totalAllowed.get();
    }

    public long getTotalBlocked() {
        return totalBlocked.get();
    }

    public long[] getStatsFor(UUID uuid) {
        return perPlayer.getOrDefault(uuid, new long[2]);
    }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        totalAllowed.set(yml.getLong("total-allowed", 0));
        totalBlocked.set(yml.getLong("total-blocked", 0));
        if (yml.isConfigurationSection("players")) {
            for (String key : yml.getConfigurationSection("players").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(key);
                    long allowed = yml.getLong("players." + key + ".allowed", 0);
                    long blocked = yml.getLong("players." + key + ".blocked", 0);
                    perPlayer.put(uuid, new long[]{allowed, blocked});
                } catch (IllegalArgumentException ignored) {
                    // skip malformed UUID entries
                }
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("total-allowed", totalAllowed.get());
        yml.set("total-blocked", totalBlocked.get());
        for (var entry : perPlayer.entrySet()) {
            String base = "players." + entry.getKey();
            yml.set(base + ".allowed", entry.getValue()[0]);
            yml.set(base + ".blocked", entry.getValue()[1]);
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save tracker.yml", e);
        }
    }
}
